import type { DiarioPasto, StatoPasto } from "../types";
import StatoChip from "./StatoChip";

const LABEL_TIPO: Record<string, string> = {
  colazione: "Colazione",
  spuntinoMattina: "Spuntino mattina",
  pranzo: "Pranzo",
  spuntinoPomeriggio: "Spuntino pomeriggio",
  cena: "Cena",
};

const ICONA_TIPO: Record<string, string> = {
  colazione: "☀️",
  spuntinoMattina: "🍎",
  pranzo: "🥗",
  spuntinoPomeriggio: "🫐",
  cena: "🌙",
};

interface Props {
  pasto: DiarioPasto;
  onStatoChange: (id: string, stato: StatoPasto) => void;
  onPorzioneChange: (pastoId: string, titoloLogico: string, porzioneId: string) => void;
}

export default function PastoCard({ pasto, onStatoChange, onPorzioneChange }: Props) {
  const vuoto = pasto.scelteEffettuate.length === 0;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-stone-100 overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3.5 border-b border-stone-100">
        <div className="flex items-center gap-2.5">
          <span className="text-xl leading-none">{ICONA_TIPO[pasto.tipo]}</span>
          <span className="font-semibold text-stone-800 text-base tracking-tight">
            {LABEL_TIPO[pasto.tipo]}
          </span>
        </div>
        <StatoChip
          stato={pasto.stato}
          onChange={(next) => onStatoChange(pasto.id, next)}
        />
      </div>

      {/* Body */}
      {vuoto ? (
        <div className="px-4 py-4 text-sm text-stone-400 italic">Nessun alimento registrato</div>
      ) : (
        <div className="px-4 py-3 space-y-3">
          {pasto.scelteEffettuate.map((scelta) => {
            const selezionata = scelta.alternative.find(
              (p) => p.id === scelta.porzioneSelezionataId
            );

            return (
              <div key={scelta.titoloLogico}>
                <p className="text-xs font-medium text-stone-400 uppercase tracking-widest mb-1.5">
                  {scelta.titoloLogico}
                </p>

                {scelta.alternative.length === 1 ? (
                  // Voce fissa (nessuna alternativa)
                  <div className="flex items-center gap-2 px-3 py-2.5 bg-stone-50 rounded-xl border border-stone-100">
                    <span className="text-sm text-stone-700 flex-1">
                      {selezionata?.quantita} {selezionata?.alimento.unitaMisura} di{" "}
                      <span className="font-medium">{selezionata?.alimento.nome}</span>
                    </span>
                    {selezionata?.note && (
                      <span className="text-xs text-stone-400">{selezionata.note}</span>
                    )}
                  </div>
                ) : (
                  // Dropdown con alternative
                  <div className="relative">
                    <select
                      value={scelta.porzioneSelezionataId}
                      onChange={(e) =>
                        onPorzioneChange(pasto.id, scelta.titoloLogico, e.target.value)
                      }
                      className="w-full appearance-none bg-stone-50 border border-stone-200 rounded-xl px-3 py-2.5 pr-9 text-sm text-stone-700 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:border-transparent transition-all"
                    >
                      {scelta.alternative.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.quantita} {p.alimento.unitaMisura} di {p.alimento.nome}
                        </option>
                      ))}
                    </select>
                    {/* Icona freccia */}
                    <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 text-xs">
                      ⇅
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Note dietologo */}
      {pasto.noteDietologo && (
        <div className="mx-4 mb-3 px-3 py-2 bg-emerald-50 rounded-xl border border-emerald-100">
          <p className="text-xs text-emerald-700">
            <span className="font-semibold">Nota: </span>
            {pasto.noteDietologo}
          </p>
        </div>
      )}
    </div>
  );
}
