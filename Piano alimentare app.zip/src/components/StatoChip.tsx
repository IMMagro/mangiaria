import type { StatoPasto } from "../types";

const STATI: StatoPasto[] = ["daConsumare", "completato", "pastoLibero", "saltato"];

const CONFIG: Record<StatoPasto, { label: string; bg: string; text: string; dot: string }> = {
  daConsumare:  { label: "Da consumare",  bg: "bg-sky-100",    text: "text-sky-700",    dot: "bg-sky-400" },
  completato:   { label: "Completato",    bg: "bg-emerald-100", text: "text-emerald-700", dot: "bg-emerald-400" },
  pastoLibero:  { label: "Pasto libero",  bg: "bg-amber-100",  text: "text-amber-700",  dot: "bg-amber-400" },
  saltato:      { label: "Saltato",       bg: "bg-red-100",    text: "text-red-600",    dot: "bg-red-400" },
};

interface Props {
  stato: StatoPasto;
  onChange: (next: StatoPasto) => void;
}

export default function StatoChip({ stato, onChange }: Props) {
  const cfg = CONFIG[stato];

  function handleTap() {
    const idx = STATI.indexOf(stato);
    onChange(STATI[(idx + 1) % STATI.length]);
  }

  return (
    <button
      onClick={handleTap}
      className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium transition-opacity active:opacity-70 ${cfg.bg} ${cfg.text}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </button>
  );
}
