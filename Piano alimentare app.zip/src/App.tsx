import { useState } from "react";
import type { DiarioGiorno, StatoPasto } from "./types";
import { mockGiornoLunedi } from "./mockData";
import PastoCard from "./components/PastoCard";

function formatData(d: Date): string {
  return d.toLocaleDateString("it-IT", { weekday: "long", day: "numeric", month: "long" });
}

export default function App() {
  const [giorno, setGiorno] = useState<DiarioGiorno>(mockGiornoLunedi);

  function handleStatoChange(pastoId: string, nuovoStato: StatoPasto) {
    setGiorno((g) => ({
      ...g,
      pasti: g.pasti.map((p) =>
        p.id === pastoId ? { ...p, stato: nuovoStato } : p
      ),
    }));
  }

  function handlePorzioneChange(pastoId: string, titoloLogico: string, porzioneId: string) {
    setGiorno((g) => ({
      ...g,
      pasti: g.pasti.map((p) => {
        if (p.id !== pastoId) return p;
        return {
          ...p,
          scelteEffettuate: p.scelteEffettuate.map((s) =>
            s.titoloLogico === titoloLogico
              ? { ...s, porzioneSelezionataId: porzioneId }
              : s
          ),
        };
      }),
    }));
  }

  const completati = giorno.pasti.filter((p) => p.stato === "completato").length;
  const totale = giorno.pasti.length;

  return (
    <div className="min-h-screen bg-stone-50 font-sans">
      {/* AppBar */}
      <header className="sticky top-0 z-10 bg-white border-b border-stone-100">
        <div className="max-w-lg mx-auto px-4 py-3.5 flex items-center justify-between">
          <div>
            <h1 className="text-lg font-bold text-stone-900 leading-tight tracking-tight">
              Diario Alimentare
            </h1>
            <p className="text-xs text-stone-400 capitalize mt-0.5">{formatData(giorno.data)}</p>
          </div>
          {/* Progress pill */}
          <div className="flex items-center gap-2">
            <div className="w-16 h-1.5 bg-stone-100 rounded-full overflow-hidden">
              <div
                className="h-full bg-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${(completati / totale) * 100}%` }}
              />
            </div>
            <span className="text-xs text-stone-400 font-medium tabular-nums">
              {completati}/{totale}
            </span>
          </div>
        </div>
      </header>

      {/* Lista pasti */}
      <main className="max-w-lg mx-auto px-4 py-5 space-y-4 pb-10">
        {giorno.pasti.map((pasto) => (
          <PastoCard
            key={pasto.id}
            pasto={pasto}
            onStatoChange={handleStatoChange}
            onPorzioneChange={handlePorzioneChange}
          />
        ))}
      </main>
    </div>
  );
}
